--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.5
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "lapanganProject";
--
-- Name: lapanganProject; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "lapanganProject" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_United States.1252';


ALTER DATABASE "lapanganProject" OWNER TO postgres;

\connect "lapanganProject"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.admin (
    id_admin integer NOT NULL,
    username_admin character varying(30) NOT NULL,
    password_admin character varying(10) NOT NULL
);


ALTER TABLE public.admin OWNER TO postgres;

--
-- Name: admin_id_admin_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.admin_id_admin_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.admin_id_admin_seq OWNER TO postgres;

--
-- Name: admin_id_admin_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.admin_id_admin_seq OWNED BY public.admin.id_admin;


--
-- Name: detail_gedung; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.detail_gedung (
    id_detail integer NOT NULL,
    gedung_id integer NOT NULL,
    nomor_lapangan character varying(30) NOT NULL
);


ALTER TABLE public.detail_gedung OWNER TO postgres;

--
-- Name: detail_gedung_id_detail_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.detail_gedung_id_detail_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.detail_gedung_id_detail_seq OWNER TO postgres;

--
-- Name: detail_gedung_id_detail_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.detail_gedung_id_detail_seq OWNED BY public.detail_gedung.id_detail;


--
-- Name: gedung; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gedung (
    id_gedung integer NOT NULL,
    nama_gedung character varying(30) NOT NULL
);


ALTER TABLE public.gedung OWNER TO postgres;

--
-- Name: gedung_id_gedung_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.gedung_id_gedung_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gedung_id_gedung_seq OWNER TO postgres;

--
-- Name: gedung_id_gedung_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.gedung_id_gedung_seq OWNED BY public.gedung.id_gedung;


--
-- Name: jam; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.jam (
    id_jam integer NOT NULL,
    jam_sewa character varying(30) NOT NULL
);


ALTER TABLE public.jam OWNER TO postgres;

--
-- Name: jam_id_jam_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.jam_id_jam_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.jam_id_jam_seq OWNER TO postgres;

--
-- Name: jam_id_jam_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.jam_id_jam_seq OWNED BY public.jam.id_jam;


--
-- Name: pemesanan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pemesanan (
    id_pemesanan integer NOT NULL,
    detail_id integer NOT NULL,
    jam_id integer NOT NULL,
    tanggal date NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.pemesanan OWNER TO postgres;

--
-- Name: pemesanan_id_pemesanan_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pemesanan_id_pemesanan_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pemesanan_id_pemesanan_seq OWNER TO postgres;

--
-- Name: pemesanan_id_pemesanan_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pemesanan_id_pemesanan_seq OWNED BY public.pemesanan.id_pemesanan;


--
-- Name: user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."user" (
    id_user integer NOT NULL,
    username_user character varying(30) NOT NULL,
    password_user character varying(10) NOT NULL
);


ALTER TABLE public."user" OWNER TO postgres;

--
-- Name: user_id_user_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_id_user_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_id_user_seq OWNER TO postgres;

--
-- Name: user_id_user_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_id_user_seq OWNED BY public."user".id_user;


--
-- Name: admin id_admin; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin ALTER COLUMN id_admin SET DEFAULT nextval('public.admin_id_admin_seq'::regclass);


--
-- Name: detail_gedung id_detail; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detail_gedung ALTER COLUMN id_detail SET DEFAULT nextval('public.detail_gedung_id_detail_seq'::regclass);


--
-- Name: gedung id_gedung; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gedung ALTER COLUMN id_gedung SET DEFAULT nextval('public.gedung_id_gedung_seq'::regclass);


--
-- Name: jam id_jam; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jam ALTER COLUMN id_jam SET DEFAULT nextval('public.jam_id_jam_seq'::regclass);


--
-- Name: pemesanan id_pemesanan; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pemesanan ALTER COLUMN id_pemesanan SET DEFAULT nextval('public.pemesanan_id_pemesanan_seq'::regclass);


--
-- Name: user id_user; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user" ALTER COLUMN id_user SET DEFAULT nextval('public.user_id_user_seq'::regclass);


--
-- Data for Name: admin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.admin (id_admin, username_admin, password_admin) FROM stdin;
\.
COPY public.admin (id_admin, username_admin, password_admin) FROM '$$PATH$$/3350.dat';

--
-- Data for Name: detail_gedung; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.detail_gedung (id_detail, gedung_id, nomor_lapangan) FROM stdin;
\.
COPY public.detail_gedung (id_detail, gedung_id, nomor_lapangan) FROM '$$PATH$$/3352.dat';

--
-- Data for Name: gedung; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gedung (id_gedung, nama_gedung) FROM stdin;
\.
COPY public.gedung (id_gedung, nama_gedung) FROM '$$PATH$$/3354.dat';

--
-- Data for Name: jam; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.jam (id_jam, jam_sewa) FROM stdin;
\.
COPY public.jam (id_jam, jam_sewa) FROM '$$PATH$$/3356.dat';

--
-- Data for Name: pemesanan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pemesanan (id_pemesanan, detail_id, jam_id, tanggal, user_id) FROM stdin;
\.
COPY public.pemesanan (id_pemesanan, detail_id, jam_id, tanggal, user_id) FROM '$$PATH$$/3358.dat';

--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."user" (id_user, username_user, password_user) FROM stdin;
\.
COPY public."user" (id_user, username_user, password_user) FROM '$$PATH$$/3360.dat';

--
-- Name: admin_id_admin_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.admin_id_admin_seq', 1, true);


--
-- Name: detail_gedung_id_detail_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.detail_gedung_id_detail_seq', 20, true);


--
-- Name: gedung_id_gedung_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.gedung_id_gedung_seq', 7, true);


--
-- Name: jam_id_jam_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.jam_id_jam_seq', 12, true);


--
-- Name: pemesanan_id_pemesanan_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pemesanan_id_pemesanan_seq', 210, true);


--
-- Name: user_id_user_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_id_user_seq', 8, false);


--
-- Name: admin admin_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admin
    ADD CONSTRAINT admin_pk PRIMARY KEY (id_admin);


--
-- Name: detail_gedung detail_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detail_gedung
    ADD CONSTRAINT detail_pk PRIMARY KEY (id_detail);


--
-- Name: gedung gedung_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gedung
    ADD CONSTRAINT gedung_pk PRIMARY KEY (id_gedung);


--
-- Name: jam jam_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.jam
    ADD CONSTRAINT jam_pk PRIMARY KEY (id_jam);


--
-- Name: pemesanan pemesanan_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pemesanan
    ADD CONSTRAINT pemesanan_pk PRIMARY KEY (id_pemesanan);


--
-- Name: user user_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pk PRIMARY KEY (id_user);


--
-- Name: detail_gedung detail_gedung_gedung_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detail_gedung
    ADD CONSTRAINT detail_gedung_gedung_id_fkey FOREIGN KEY (gedung_id) REFERENCES public.gedung(id_gedung);


--
-- Name: pemesanan detail_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pemesanan
    ADD CONSTRAINT detail_id FOREIGN KEY (detail_id) REFERENCES public.detail_gedung(id_detail);


--
-- Name: pemesanan jam; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pemesanan
    ADD CONSTRAINT jam FOREIGN KEY (jam_id) REFERENCES public.jam(id_jam);


--
-- Name: pemesanan user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pemesanan
    ADD CONSTRAINT user_id FOREIGN KEY (user_id) REFERENCES public."user"(id_user);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

REVOKE ALL ON SCHEMA public FROM "Lenovo";
REVOKE ALL ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO pg_database_owner;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

